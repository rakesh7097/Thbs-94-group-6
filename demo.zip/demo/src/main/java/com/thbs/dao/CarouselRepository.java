package com.thbs.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.thbs.model.Carousel;

public interface CarouselRepository extends JpaRepository<Carousel, Long> {

}