package com.thbs.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.thbs.model.CartItem;

@Repository
public interface CartItemRepository extends JpaRepository<CartItem,Long> {

}